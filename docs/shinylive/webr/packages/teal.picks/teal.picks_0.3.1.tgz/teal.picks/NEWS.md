# teal.picks 0.3.1

### Enhancements

* Removes warning when `values(multiple = FALSE)` when `choices` and `selected` are the default function (#118).
* Export new helpers for module developers: `ensure_picks_datasets()` and `picks_datanames()` (#123).
* Set minimum version requirements for dependencies.

### Bug fixes

* Fixed the `fixed` attribute automatic value in `datasets()`, `variables()` and `values()` when single-choice is provided, but selected is different (#125).
* Warnings about explicit selection but delayed choices are triggered when resolving the issues (#117).
* `picks_ui()` works with lists and picks objects (#136).
* Suggested dependency `teal.transform` is no longer needed for running examples (#134).
* Merging keeps primary keys (#119).

# teal.picks 0.3.0

### Enhancements

* Fixed `variables` selection popup to show "Select all"/"Deselect all" when multiple selection is enabled.
* Adds assertion to check for specific elements of picks to API.
* Warnings from internal functions checking picks don't spill code (#109)

### Bug fixes

* Fixed a bug that crashes the `picks_srv` when datasets with labels that contain lists. Defaults to the choice name (#96).
* `merge_srv` keeps all `join_keys` of the data (#103).
* `merge_srv` assign the output to specified `output_name` (#101).
* Fixed warning appearing when labels attribute being used in datasets.

# teal.picks 0.2.0

### Miscellaneous

* `variables()` allows for custom `allow-clear` options to be set by user without being overwritten.
* Improve badge border and looks.
* Update maintainer.

# teal.picks 0.1.0

### New Features

* Added `picks()`, `datasets()`, `variables()`, and `values()` functions for defining hierarchical data selections (dataset -> variable -> value).
* Added `picks_ui()` and `picks_srv()` Shiny modules for interactive selection widgets with badge drop-down UI.
* Added `resolver()` to resolve delayed and dynamic choices using `tidyselect` expressions and predicate functions.
* Added `merge_srv()` for merging multiple datasets based on picks selections, with automatic join key detection and conflict resolution.
* Added `tm_merge()` teal module for interactive dataset merging with generated R code.
* Added `as.picks()` for converting `teal.transform::data_extract_spec` objects to picks.
* Added `teal_transform_filter()` for creating filter transformers from picks selections.
* Added `is_categorical()` `tidyselect` helper for selecting categorical variables with cardinality constraints.

### Miscellaneous

* Initial public release.
