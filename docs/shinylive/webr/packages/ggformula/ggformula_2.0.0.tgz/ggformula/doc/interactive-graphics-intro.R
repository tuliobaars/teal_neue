## -----------------------------------------------------------------------------
#| label: setup
#| include: false
library(ggformula)
theme_set(theme_bw())


## -----------------------------------------------------------------------------
#| label: static-example
mtcars2 <- mtcars |> tibble::rownames_to_column(var = "carname")

mtcars2 |>
  gf_point(wt ~ drat, color = ~mpg, size = 3)

