## ----setup, include = FALSE---------------------------------------------------
have_packages <-
  require(ggformula) &&
  require(ggplot2) &&
  requireNamespace("ggrepel") &&
  requireNamespace("ggdist")

knitr::opts_chunk$set(
  fig.show = "asis",
  fig.align = "center",
  fig.width = 6,
  fig.height = 4,
  out.width = "60%",
  eval = have_packages
)
theme_set(theme_light())




## ----inspect-spec-------------------------------------------------------------
ggformula_spec(gf_point) |> str()


## -----------------------------------------------------------------------------
ggformula_spec(gf_text) |> getElement('pre')


## ----gf-text-repel-definition-------------------------------------------------
library(ggrepel)

gf_text_repel <-
  layer_factory(
    geom = "text_repel",
    layer_fun = rlang::quo(ggrepel::geom_text_repel),
    extras = alist(
      label = ,
      alpha = ,
      color = ,
      size = ,
      fontface = ,
      family = ,
      box.padding = 0.25,
      point.padding = 1e-06,
      min.segment.length = 0.5,
      max.overlaps = 10,
      nudge_x = 0,
      nudge_y = 0,
      seed = NA,
      direction = "both"
    )
  )


## ----gf-text-repel-example----------------------------------------------------
df <- data.frame(
  x = c(1, 2, 3, 2.9, 5),
  y = c(3, 1, 4, 4, 5),
  name = c("apple", "banana", "cherry", "date", "elderberry")
)

gf_point(y ~ x, data = df) |>
  gf_text_repel(y ~ x, label = ~name, seed = 1234)


## ----gf-text-example----------------------------------------------------------
gf_point(y ~ x, data = df) |>
  gf_text(y ~ x, label = ~name, nudge_y = 0.3)


## ----gf-halfeye-definition----------------------------------------------------
library(ggdist)

gf_halfeye <-
  layer_factory(
    geom = "slabinterval",
    stat = "halfeye",
    layer_fun = rlang::quo(ggdist::stat_halfeye),
    extras = alist(
      fill = ,
      color = ,
      alpha = ,
      adjust = 1,
      point_interval = "median_qi",
      .width = c(0.66, 0.95),
      side = "top",
      justification = NULL
    )
  )


## ----gf-halfeye-example-------------------------------------------------------
set.seed(202)
scores <- data.frame(
  section = rep(c("A", "B", "C"), each = 30),
  score = c(rnorm(30, 78, 6), rnorm(30, 82, 9), rnorm(30, 75, 5))
)

gf_halfeye(score ~ section, data = scores, fill = ~section, show.legend = FALSE)

